<script setup lang="ts">

</script>

<template>
    <nav>
        <RouterLink to="/">Reportes</RouterLink>
        <RouterLink to="/reports/create">Nuevo reportes</RouterLink>
    </nav>
    <RouterView />
</template>
